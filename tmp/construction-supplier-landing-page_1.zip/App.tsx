
import React, { useState, useEffect } from 'react';
import Hero from './components/Hero';
import Services from './components/Services';
import About from './components/About';
import Projects from './components/Projects';
import ProjectModal from './components/ProjectModal';
import Testimonials from './components/Testimonials';
import Footer from './components/Footer';
import { BUSINESS_DATA } from './constants';
import { Menu, Phone, X, Palette } from 'lucide-react';
import { Project, TemplateId } from './types';

const App: React.FC = () => {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [currentTemplate, setCurrentTemplate] = useState<TemplateId>('industrial');
  const [isSwitcherOpen, setIsSwitcherOpen] = useState(false);

  // Template configuration mapping
  const themes: Record<TemplateId, { bodyClass: string; navClass: string; accentColor: string; font: string }> = {
    industrial: {
      bodyClass: 'bg-slate-50 font-industrial',
      navClass: 'bg-white/90 border-slate-100',
      accentColor: 'amber-500',
      font: 'font-industrial'
    },
    luxury: {
      bodyClass: 'bg-zinc-950 text-zinc-100 font-luxury',
      navClass: 'bg-zinc-900/95 border-zinc-800',
      accentColor: 'yellow-600',
      font: 'font-luxury'
    },
    corporate: {
      bodyClass: 'bg-white text-gray-900 font-corporate',
      navClass: 'bg-white border-blue-100 shadow-sm',
      accentColor: 'blue-700',
      font: 'font-corporate'
    },
    modern: {
      bodyClass: 'bg-gray-50 text-slate-900 font-modern',
      navClass: 'bg-white/70 backdrop-blur-xl border-indigo-50',
      accentColor: 'indigo-600',
      font: 'font-modern'
    }
  };

  const theme = themes[currentTemplate];

  return (
    <div className={`min-h-screen transition-all duration-500 ${theme.bodyClass} ${theme.font}`}>
      {/* Template Switcher UI */}
      <div className="fixed top-24 left-4 z-[60]">
        <button 
          onClick={() => setIsSwitcherOpen(!isSwitcherOpen)}
          className="bg-white shadow-2xl p-3 rounded-full text-slate-900 hover:rotate-90 transition-transform border border-slate-200"
        >
          <Palette size={24} />
        </button>
        {isSwitcherOpen && (
          <div className="absolute top-14 left-0 bg-white shadow-2xl rounded-2xl p-4 border border-slate-100 flex flex-col gap-2 min-w-[160px] animate-in fade-in slide-in-from-left-4 duration-300">
            <p className="text-xs font-bold text-slate-400 mb-1 px-2">בחר תבנית עיצוב:</p>
            {[
              { id: 'industrial', label: 'תעשייתי (ברירת מחדל)', color: 'bg-amber-500' },
              { id: 'luxury', label: 'יוקרה אפל', color: 'bg-zinc-900' },
              { id: 'corporate', label: 'עסקי נקי', color: 'bg-blue-700' },
              { id: 'modern', label: 'טק מודרני', color: 'bg-indigo-600' }
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => {
                  setCurrentTemplate(t.id as TemplateId);
                  setIsSwitcherOpen(false);
                }}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-bold transition-colors ${currentTemplate === t.id ? 'bg-slate-100 text-slate-900' : 'text-slate-600 hover:bg-slate-50'}`}
              >
                <div className={`w-3 h-3 rounded-full ${t.color}`}></div>
                {t.label}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className={`sticky top-0 z-50 backdrop-blur-md border-b transition-colors duration-500 ${theme.navClass}`}>
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
             <div className={`w-8 h-8 rotate-45 flex items-center justify-center transition-colors duration-500 ${
               currentTemplate === 'luxury' ? 'bg-yellow-600' : 
               currentTemplate === 'corporate' ? 'bg-blue-700' : 
               currentTemplate === 'modern' ? 'bg-indigo-600' : 'bg-amber-500'
             }`}>
                 <div className="w-4 h-4 border-2 border-white -rotate-45"></div>
              </div>
            <span className={`text-2xl font-bold tracking-tighter ${currentTemplate === 'luxury' ? 'text-white' : 'text-slate-900'}`}>{BUSINESS_DATA.name}</span>
          </div>
          
          <div className="hidden md:flex items-center gap-8">
            <a href="#services" className={`font-semibold transition-colors ${currentTemplate === 'luxury' ? 'text-zinc-400 hover:text-yellow-500' : 'text-slate-600 hover:text-amber-600'}`}>שירותים</a>
            <a href="#projects" className={`font-semibold transition-colors ${currentTemplate === 'luxury' ? 'text-zinc-400 hover:text-yellow-500' : 'text-slate-600 hover:text-amber-600'}`}>פרויקטים</a>
            <a href="#about" className={`font-semibold transition-colors ${currentTemplate === 'luxury' ? 'text-zinc-400 hover:text-yellow-500' : 'text-slate-600 hover:text-amber-600'}`}>אודות</a>
            <a 
              href={`tel:${BUSINESS_DATA.phone}`}
              className={`px-6 py-2 rounded-full font-bold flex items-center gap-2 transition-all shadow-lg ${
                currentTemplate === 'luxury' ? 'bg-yellow-600 text-zinc-900 hover:bg-yellow-500' : 
                currentTemplate === 'corporate' ? 'bg-blue-700 text-white hover:bg-blue-800' : 
                currentTemplate === 'modern' ? 'bg-indigo-600 text-white hover:bg-indigo-700' : 'bg-slate-900 text-white hover:bg-slate-800'
              }`}
            >
              <Phone size={16} />
              הצעת מחיר
            </a>
          </div>
          
          <button 
            className={`md:hidden ${currentTemplate === 'luxury' ? 'text-white' : 'text-slate-900'}`}
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className={`md:hidden border-b p-4 space-y-4 animate-in slide-in-from-top duration-300 ${currentTemplate === 'luxury' ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-slate-100'}`}>
            <a href="#services" onClick={() => setIsMenuOpen(false)} className={`block font-bold p-2 ${currentTemplate === 'luxury' ? 'text-white' : 'text-slate-800'}`}>שירותים</a>
            <a href="#projects" onClick={() => setIsMenuOpen(false)} className={`block font-bold p-2 ${currentTemplate === 'luxury' ? 'text-white' : 'text-slate-800'}`}>פרויקטים</a>
            <a href="#about" onClick={() => setIsMenuOpen(false)} className={`block font-bold p-2 ${currentTemplate === 'luxury' ? 'text-white' : 'text-slate-800'}`}>אודות</a>
            <a href={`tel:${BUSINESS_DATA.phone}`} className={`block text-center py-3 rounded-xl font-bold ${
              currentTemplate === 'luxury' ? 'bg-yellow-600 text-zinc-950' : 'bg-amber-500 text-slate-900'
            }`}>התקשרו עכשיו</a>
          </div>
        )}
      </nav>

      <main>
        <Hero template={currentTemplate} />
        <Services template={currentTemplate} />
        <Projects onSelectProject={setSelectedProject} template={currentTemplate} />
        <About template={currentTemplate} />
        <Testimonials template={currentTemplate} />
      </main>

      <Footer template={currentTemplate} />

      {/* Project Gallery Modal */}
      <ProjectModal 
        project={selectedProject} 
        onClose={() => setSelectedProject(null)} 
        template={currentTemplate}
      />
    </div>
  );
};

export default App;
