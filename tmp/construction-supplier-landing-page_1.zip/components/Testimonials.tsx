
import React from 'react';
import { TESTIMONIALS } from '../constants';
import { Quote } from 'lucide-react';
import { TemplateId } from '../types';

interface TestimonialsProps {
  template: TemplateId;
}

// Add template prop to Testimonials component to support multi-theme styling
const Testimonials: React.FC<TestimonialsProps> = ({ template }) => {
  const isLuxury = template === 'luxury';
  const isModern = template === 'modern';
  const isCorporate = template === 'corporate';

  return (
    <section className={`py-20 transition-colors duration-500 ${isLuxury ? 'bg-zinc-950' : 'bg-white'}`}>
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className={`text-3xl md:text-4xl font-bold mb-4 transition-colors duration-500 ${isLuxury ? 'text-white font-serif' : 'text-slate-900'}`}>מה הלקוחות אומרים</h2>
          <div className={`w-20 h-1 mx-auto transition-colors duration-500 ${
            isLuxury ? 'bg-yellow-600' : 
            isModern ? 'bg-indigo-600' : 
            isCorporate ? 'bg-blue-700' : 'bg-amber-500'
          }`}></div>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {TESTIMONIALS.map((t) => (
            <div key={t.id} className={`p-8 relative transition-all duration-500 ${
              isLuxury ? 'bg-zinc-900 border border-zinc-800 rounded-none' : 'bg-slate-50 rounded-3xl'
            }`}>
              <Quote className={`absolute top-4 left-4 transition-colors duration-500 ${
                isLuxury ? 'text-yellow-600/20' : 'text-amber-500/20'
              }`} size={64} />
              <p className={`text-lg italic mb-6 relative z-10 transition-colors duration-500 ${isLuxury ? 'text-zinc-400' : 'text-slate-700'}`}>"{t.text}"</p>
              <div>
                <h4 className={`font-bold text-xl transition-colors duration-500 ${isLuxury ? 'text-zinc-100' : 'text-slate-900'}`}>{t.name}</h4>
                <p className={`transition-colors duration-500 ${
                  isLuxury ? 'text-yellow-600' : isModern ? 'text-indigo-600' : isCorporate ? 'text-blue-700' : 'text-amber-600'
                }`}>{t.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
