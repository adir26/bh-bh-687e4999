
import React from 'react';
import { Project, TemplateId } from '../types';
import { X, MapPin } from 'lucide-react';

interface ProjectModalProps {
  project: Project | null;
  onClose: () => void;
  template: TemplateId;
}

const ProjectModal: React.FC<ProjectModalProps> = ({ project, onClose, template }) => {
  if (!project) return null;

  const isLuxury = template === 'luxury';
  const isModern = template === 'modern';

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-slate-900/95 backdrop-blur-sm"
        onClick={onClose}
      ></div>
      
      {/* Modal Content */}
      <div className={`relative w-full max-w-6xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl animate-in fade-in zoom-in duration-300 transition-colors ${
        isLuxury ? 'bg-zinc-900 text-zinc-100 rounded-none border border-zinc-800' : 
        isModern ? 'bg-white text-slate-900 rounded-[3rem]' :
        'bg-white text-slate-900 rounded-3xl'
      }`}>
        <button 
          onClick={onClose}
          className={`absolute top-6 right-6 z-50 p-2 rounded-full transition-colors ${
            isLuxury ? 'bg-zinc-800 text-zinc-400 hover:text-white' : 'bg-slate-100 text-slate-900 hover:bg-slate-200'
          }`}
        >
          <X size={24} />
        </button>

        <div className="overflow-y-auto">
          <div className={`p-8 md:p-12 border-b ${isLuxury ? 'border-zinc-800' : 'border-slate-100'}`}>
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
              <div>
                <div className={`flex items-center gap-2 font-bold mb-2 ${
                  isLuxury ? 'text-yellow-600 uppercase tracking-widest text-sm' : 'text-amber-600'
                }`}>
                  <MapPin size={18} />
                  {project.location}
                </div>
                <h2 className={`text-3xl md:text-5xl font-bold ${isLuxury ? 'font-serif italic' : ''}`}>
                  {project.title}
                </h2>
              </div>
            </div>
            <p className={`mt-8 text-lg leading-relaxed max-w-4xl ${isLuxury ? 'text-zinc-400 italic' : 'text-slate-600'}`}>
              {project.description}
            </p>
          </div>

          <div className="p-8 md:p-12">
            <h3 className={`text-2xl font-bold mb-8 ${isLuxury ? 'font-serif text-yellow-600' : ''}`}>
              גלריית תמונות מהשטח
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {project.gallery.map((img, idx) => (
                <div key={idx} className={`aspect-[4/3] overflow-hidden shadow-lg group ${
                  isLuxury ? 'rounded-none border border-zinc-800' : isModern ? 'rounded-[2rem]' : 'rounded-2xl'
                }`}>
                  <img 
                    src={img} 
                    alt={`${project.title} - ${idx + 1}`} 
                    className="w-full h-full object-cover hover:scale-110 transition-transform duration-700 cursor-zoom-in"
                    onClick={() => window.open(img, '_blank')}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className={`p-8 border-t flex justify-center ${isLuxury ? 'bg-zinc-950 border-zinc-800' : 'bg-slate-50 border-slate-100'}`}>
          <button 
            onClick={onClose}
            className={`px-12 py-4 rounded-full font-bold transition-all transform hover:scale-105 ${
              isLuxury ? 'bg-yellow-600 text-zinc-950 hover:bg-yellow-500' : 
              isModern ? 'bg-indigo-600 text-white' : 
              'bg-slate-900 text-white'
            }`}
          >
            סגור גלריה
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProjectModal;
