
import React from 'react';
import { Phone, MessageCircle } from 'lucide-react';
import { BUSINESS_DATA } from '../constants';
import { TemplateId } from '../types';

interface HeroProps {
  template: TemplateId;
}

const Hero: React.FC<HeroProps> = ({ template }) => {
  const isLuxury = template === 'luxury';
  const isModern = template === 'modern';
  const isCorporate = template === 'corporate';

  return (
    <section className={`relative h-[90vh] flex items-center justify-center overflow-hidden transition-colors duration-500 ${isLuxury ? 'bg-zinc-950' : 'bg-slate-900'}`}>
      {/* Background Image with Dynamic Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1541913057-9556e51167bd?auto=format&fit=crop&q=80&w=1600" 
          alt="Construction Site" 
          className={`w-full h-full object-cover transition-opacity duration-1000 ${isLuxury ? 'opacity-20 grayscale' : 'opacity-40'}`}
        />
        <div className={`absolute inset-0 bg-gradient-to-b ${
          isLuxury ? 'from-zinc-950/80 to-zinc-950' : 
          isModern ? 'from-indigo-900/40 to-slate-900/90' :
          'from-slate-900/60 to-slate-900/90'
        }`}></div>
      </div>

      <div className="relative z-10 container mx-auto px-4 text-center text-white">
        <h1 className={`mb-6 leading-tight transition-all duration-500 ${
          isLuxury ? 'text-5xl md:text-8xl font-serif italic' : 
          isModern ? 'text-5xl md:text-7xl font-black uppercase tracking-tighter' :
          'text-4xl md:text-6xl lg:text-7xl font-extrabold'
        }`}>
          בונים את ישראל <br /> 
          <span className={`${
            isLuxury ? 'text-yellow-600' : 
            isModern ? 'bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 to-emerald-400' :
            isCorporate ? 'text-blue-500' :
            'text-amber-500'
          }`}>
            {isLuxury ? 'באלגנטיות נצחית' : 'בסטנדרט של המחר'}
          </span>
        </h1>
        <p className={`mb-10 max-w-3xl mx-auto leading-relaxed transition-all duration-500 ${
          isLuxury ? 'text-xl md:text-2xl font-light text-zinc-400 italic' :
          isModern ? 'text-lg md:text-xl font-medium text-slate-300' :
          'text-xl md:text-2xl font-light'
        }`}>
          {BUSINESS_DATA.name}: מומחים במערכות אלומיניום, חיפויים ועבודות גמר. {BUSINESS_DATA.advantage}.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <a 
            href={`https://wa.me/${BUSINESS_DATA.whatsapp}`}
            className={`flex items-center gap-2 px-8 py-4 rounded-full text-xl font-bold transition-all transform hover:scale-105 shadow-xl w-full sm:w-auto justify-center ${
              isLuxury ? 'border border-zinc-800 hover:bg-zinc-800' : 'bg-green-600 hover:bg-green-700 text-white'
            }`}
          >
            <MessageCircle size={24} />
            וואטסאפ
          </a>
          <a 
            href={`tel:${BUSINESS_DATA.phone}`}
            className={`flex items-center gap-2 px-8 py-4 rounded-full text-xl font-bold transition-all transform hover:scale-105 shadow-xl w-full sm:w-auto justify-center ${
              isLuxury ? 'bg-yellow-600 text-zinc-950 hover:bg-yellow-500' : 
              isModern ? 'bg-indigo-600 text-white hover:bg-indigo-700' :
              isCorporate ? 'bg-blue-700 text-white' :
              'bg-amber-500 text-slate-900 hover:bg-amber-600'
            }`}
          >
            <Phone size={24} />
            התקשרו עכשיו
          </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;
