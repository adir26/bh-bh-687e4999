
import React from 'react';
import { PROJECTS } from '../constants';
import { MapPin, Eye } from 'lucide-react';
import { Project, TemplateId } from '../types';

interface ProjectsProps {
  onSelectProject: (project: Project) => void;
  template: TemplateId;
}

const Projects: React.FC<ProjectsProps> = ({ onSelectProject, template }) => {
  const isLuxury = template === 'luxury';
  const isModern = template === 'modern';
  const isCorporate = template === 'corporate';

  return (
    <section id="projects" className={`py-20 transition-colors duration-500 ${isLuxury ? 'bg-zinc-950 border-y border-zinc-800' : 'bg-slate-50'}`}>
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className={`text-3xl md:text-4xl font-bold mb-4 transition-colors duration-500 ${isLuxury ? 'text-white font-serif' : 'text-slate-900'}`}>
            פרויקטים נבחרים
          </h2>
          <p className={`text-lg max-w-2xl mx-auto transition-colors duration-500 ${isLuxury ? 'text-zinc-400 italic' : 'text-slate-600'}`}>
            מבט אל חלק מהעבודות האחרונות שלנו בפריסה ארצית. איכות וביצוע ללא פשרות.
          </p>
          <div className={`w-20 h-1 mx-auto mt-6 transition-colors duration-500 ${
            isLuxury ? 'bg-yellow-600' : 
            isModern ? 'bg-indigo-600' : 
            'bg-amber-500'
          }`}></div>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {PROJECTS.map((project) => (
            <div 
              key={project.id}
              className={`group overflow-hidden transition-all duration-300 cursor-pointer ${
                isLuxury ? 'bg-zinc-900 border border-zinc-800 rounded-none' : 
                isModern ? 'bg-white rounded-[2.5rem] shadow-lg hover:shadow-2xl' :
                'bg-white rounded-2xl shadow-sm hover:shadow-xl border border-slate-100'
              }`}
              onClick={() => onSelectProject(project)}
            >
              <div className="relative h-72 overflow-hidden">
                <img 
                  src={project.mainImage} 
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className={`absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm ${
                  isLuxury ? 'bg-zinc-950/60' : 'bg-slate-900/40'
                }`}>
                  <span className={`px-6 py-3 rounded-full font-bold flex items-center gap-2 transition-all ${
                    isLuxury ? 'bg-yellow-600 text-zinc-950' : 
                    isModern ? 'bg-indigo-600 text-white' : 
                    'bg-amber-500 text-slate-900'
                  }`}>
                    <Eye size={18} /> לצפייה בגלריה
                  </span>
                </div>
              </div>
              <div className="p-8">
                <div className={`flex items-center gap-1 text-sm font-semibold mb-3 ${
                  isLuxury ? 'text-yellow-600 uppercase tracking-widest' : 
                  isModern ? 'text-indigo-600' : 
                  'text-amber-600'
                }`}>
                  <MapPin size={14} />
                  {project.location}
                </div>
                <h3 className={`text-2xl font-bold mb-3 ${isLuxury ? 'text-zinc-100 font-serif' : 'text-slate-900'}`}>
                  {project.title}
                </h3>
                <p className={`text-base leading-relaxed line-clamp-2 ${isLuxury ? 'text-zinc-500' : 'text-slate-600'}`}>
                  {project.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;
