
import React from 'react';
import { SERVICES } from '../constants';
import * as Icons from 'lucide-react';
import { TemplateId } from '../types';

interface ServicesProps {
  template: TemplateId;
}

const Services: React.FC<ServicesProps> = ({ template }) => {
  const isLuxury = template === 'luxury';
  const isModern = template === 'modern';
  const isCorporate = template === 'corporate';

  return (
    <section id="services" className={`py-20 transition-colors duration-500 ${isLuxury ? 'bg-zinc-900' : 'bg-white'}`}>
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className={`text-3xl md:text-4xl font-bold mb-4 transition-colors duration-500 ${isLuxury ? 'text-white font-serif italic' : 'text-slate-900'}`}>
            השירותים שלנו
          </h2>
          <div className={`w-20 h-1 mx-auto transition-colors duration-500 ${
            isLuxury ? 'bg-yellow-600' : 
            isModern ? 'bg-indigo-600' : 
            isCorporate ? 'bg-blue-700' : 'bg-amber-500'
          }`}></div>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {SERVICES.map((service) => {
            const IconComponent = (Icons as any)[service.icon];
            return (
              <div 
                key={service.id} 
                className={`p-8 transition-all duration-300 group ${
                  isLuxury ? 'bg-zinc-800/50 border border-zinc-700 hover:border-yellow-600 rounded-none' : 
                  isModern ? 'bg-white border-none shadow-xl shadow-slate-200/50 rounded-3xl hover:-translate-y-2' :
                  isCorporate ? 'bg-white border border-slate-100 rounded-lg shadow-sm' :
                  'bg-slate-50 border border-slate-100 rounded-2xl'
                }`}
              >
                <div className={`w-16 h-16 flex items-center justify-center mb-6 transition-all ${
                  isLuxury ? 'text-yellow-600 border border-yellow-600/30 group-hover:bg-yellow-600 group-hover:text-zinc-900' : 
                  isModern ? 'bg-indigo-100 text-indigo-600 rounded-2xl group-hover:bg-indigo-600 group-hover:text-white' :
                  isCorporate ? 'text-blue-700' :
                  'bg-amber-500/10 text-amber-600 rounded-xl group-hover:bg-amber-500 group-hover:text-white'
                }`}>
                  {IconComponent && <IconComponent size={32} />}
                </div>
                <h3 className={`text-2xl font-bold mb-4 transition-colors duration-500 ${isLuxury ? 'text-zinc-100 font-serif' : 'text-slate-900'}`}>
                  {service.title}
                </h3>
                <p className={`leading-relaxed text-lg transition-colors duration-500 ${isLuxury ? 'text-zinc-400' : 'text-slate-600'}`}>
                  {service.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Services;
