
import React from 'react';
import { BUSINESS_DATA, LOGO_DESCRIPTION } from '../constants';
import { Phone, Mail, MapPin, MessageCircle } from 'lucide-react';
import { TemplateId } from '../types';

interface FooterProps {
  template: TemplateId;
}

const Footer: React.FC<FooterProps> = ({ template }) => {
  const isLuxury = template === 'luxury';
  const isModern = template === 'modern';

  return (
    <footer className={`transition-colors duration-500 pt-20 pb-20 md:pb-10 ${isLuxury ? 'bg-zinc-950 text-zinc-100 border-t border-zinc-900' : 'bg-slate-900 text-white'}`}>
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-12 mb-16">
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className={`w-10 h-10 rotate-45 flex items-center justify-center transition-colors ${
                isLuxury ? 'bg-yellow-600' : isModern ? 'bg-indigo-600' : 'bg-amber-500'
              }`}>
                 <div className="w-6 h-6 border-2 border-white -rotate-45"></div>
              </div>
              <span className={`text-3xl font-bold tracking-tighter ${isLuxury ? 'font-serif italic' : ''}`}>
                {BUSINESS_DATA.name}
              </span>
            </div>
            <p className={`mb-4 text-lg ${isLuxury ? 'text-zinc-500 italic' : 'text-slate-400'}`}>
              מביאים חדשנות, איכות ואמינות לכל אתר בנייה. השותפים שלך להצלחה בשטח.
            </p>
          </div>

          <div>
            <h4 className={`text-xl font-bold mb-6 ${isLuxury ? 'text-yellow-600 font-serif uppercase tracking-widest' : 'text-amber-500'}`}>יצירת קשר</h4>
            <ul className="space-y-4">
              <li className={`flex items-center gap-3 ${isLuxury ? 'text-zinc-400' : 'text-slate-300'}`}>
                <Phone size={20} className={isLuxury ? 'text-yellow-600' : 'text-amber-500'} />
                <a href={`tel:${BUSINESS_DATA.phone}`} dir="ltr">{BUSINESS_DATA.phone}</a>
              </li>
              <li className={`flex items-center gap-3 ${isLuxury ? 'text-zinc-400' : 'text-slate-300'}`}>
                <Mail size={20} className={isLuxury ? 'text-yellow-600' : 'text-amber-500'} />
                <a href={`mailto:${BUSINESS_DATA.email}`}>{BUSINESS_DATA.email}</a>
              </li>
              <li className={`flex items-center gap-3 ${isLuxury ? 'text-zinc-400' : 'text-slate-300'}`}>
                <MapPin size={20} className={isLuxury ? 'text-yellow-600' : 'text-amber-500'} />
                <span>{BUSINESS_DATA.area}</span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className={`text-xl font-bold mb-6 ${isLuxury ? 'text-yellow-600 font-serif uppercase tracking-widest' : 'text-amber-500'}`}>הנחיות עיצוב</h4>
            <p className={`text-sm leading-relaxed italic border-r-2 pr-4 ${isLuxury ? 'text-zinc-600 border-zinc-800' : 'text-slate-400 border-amber-500/30'}`}>
              {LOGO_DESCRIPTION}
            </p>
          </div>
        </div>

        <div className={`border-t pt-8 text-center ${isLuxury ? 'border-zinc-900 text-zinc-700' : 'border-slate-800 text-slate-500'}`}>
          <p>© {new Date().getFullYear()} {BUSINESS_DATA.name} פתרונות בנייה. כל הזכויות שמורות.</p>
        </div>
      </div>

      {/* Persistent CTA for Mobile */}
      <div className={`fixed bottom-0 left-0 right-0 border-t p-3 flex gap-3 md:hidden z-50 ${isLuxury ? 'bg-zinc-900 border-zinc-800' : 'bg-white'}`}>
        <a 
          href={`tel:${BUSINESS_DATA.phone}`} 
          className={`flex-1 py-3 rounded-xl font-bold flex items-center justify-center gap-2 ${
            isLuxury ? 'bg-zinc-800 text-white' : 'bg-slate-900 text-white'
          }`}
        >
          <Phone size={18} /> התקשר
        </a>
        <a 
          href={`https://wa.me/${BUSINESS_DATA.whatsapp}`} 
          className="flex-1 bg-green-600 text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2"
        >
          <MessageCircle size={18} /> וואטסאפ
        </a>
      </div>
    </footer>
  );
};

export default Footer;
