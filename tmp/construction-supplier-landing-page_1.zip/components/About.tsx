
import React from 'react';
import { CheckCircle2 } from 'lucide-react';
import { WHY_CHOOSE_US, BUSINESS_DATA } from '../constants';
import { TemplateId } from '../types';

interface AboutProps {
  template: TemplateId;
}

// Add template prop to About component to support multi-theme styling
const About: React.FC<AboutProps> = ({ template }) => {
  const isLuxury = template === 'luxury';
  const isModern = template === 'modern';

  return (
    <section id="about" className={`py-20 transition-colors duration-500 ${isLuxury ? 'bg-zinc-900 border-b border-zinc-800' : 'bg-slate-50'}`}>
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          <div className="lg:w-1/2">
            <h2 className={`text-3xl md:text-4xl font-bold mb-6 transition-colors duration-500 ${isLuxury ? 'text-white font-serif' : 'text-slate-900'}`}>קצת עלינו</h2>
            <p className={`text-xl leading-relaxed mb-8 transition-colors duration-500 ${isLuxury ? 'text-zinc-400' : 'text-slate-700'}`}>
              חברת <span className={`font-bold ${isLuxury ? 'text-yellow-600' : isModern ? 'text-indigo-600' : 'text-amber-600'}`}>{BUSINESS_DATA.name}</span> הוקמה מתוך חזון לספק לשוק הבנייה הישראלי פתרונות אלומיניום וגמר המשלבים הנדסה מדויקת ועיצוב מרהיב. 
              אנו מתמחים בביצוע פרויקטים מורכבים בפריסה ארצית, תוך שימוש בחומרי הגלם הטובים ביותר וצוותי התקנה מיומנים.
            </p>
            
            <h3 className={`text-2xl font-bold mb-6 transition-colors duration-500 ${isLuxury ? 'text-white' : 'text-slate-900'}`}>למה לבחור דווקא בנו?</h3>
            <ul className="space-y-4">
              {WHY_CHOOSE_US.map((item, index) => (
                <li key={index} className="flex items-start gap-3">
                  <CheckCircle2 className={`shrink-0 mt-1 ${isLuxury ? 'text-yellow-600' : isModern ? 'text-indigo-600' : 'text-amber-500'}`} size={24} />
                  <span className={`text-lg transition-colors duration-500 ${isLuxury ? 'text-zinc-400' : 'text-slate-700'}`}>{item}</span>
                </li>
              ))}
            </ul>
          </div>
          
          <div className="lg:w-1/2 grid grid-cols-2 gap-4">
            <img src="https://picsum.photos/id/101/400/500" alt="Projects 1" className={`shadow-lg w-full h-full object-cover ${isLuxury ? 'rounded-none border border-zinc-800' : 'rounded-2xl'}`} />
            <img src="https://picsum.photos/id/102/400/500" alt="Projects 2" className={`shadow-lg w-full h-full object-cover translate-y-8 ${isLuxury ? 'rounded-none border border-zinc-800' : 'rounded-2xl'}`} />
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
