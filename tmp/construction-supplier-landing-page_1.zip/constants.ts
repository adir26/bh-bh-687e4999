
import { BusinessInfo, Service, Testimonial, Project } from './types';

export const BUSINESS_DATA: BusinessInfo = {
  name: "בוני הארץ",
  specialty: "אלומיניום, מערכות גמר וחיפויים",
  area: "אזור המרכז, השרון והשפלה",
  advantage: "איכות ללא פשרות, עמידה בלוחות זמנים ומחיר תחרותי ישירות מהיצרן",
  phone: "050-1234567",
  whatsapp: "972501234567",
  email: "office@builders-israel.co.il"
};

export const SERVICES: Service[] = [
  {
    id: 1,
    title: "חלונות ודלתות אלומיניום",
    description: "ייצור והתקנה של מערכות אלומיניום מתקדמות (קליל, מאווי) ברמת גימור בוטיק.",
    icon: "Window"
  },
  {
    id: 2,
    title: "חיפויי חוץ דקורטיביים",
    description: "חיפוי HPL, אלומיניום דמוי עץ ופתרונות הצללה חכמים למבני מגורים ותעשייה.",
    icon: "Layout"
  },
  {
    id: 3,
    title: "עבודות גמר ומחיצות",
    description: "פתרונות חלוקת חלל למשרדים ובתים פרטיים המשלבים זכוכית, פלדה ועץ.",
    icon: "Box"
  }
];

export const PROJECTS: Project[] = [
  {
    id: 1,
    title: "וילה יוקרתית - צהלה",
    description: "ביצוע מערכות אלומיניום דקיקות מסדרת מינימל, חלונות הזזה ענקיים וחיפוי אלומיניום דמוי עץ בכניסה.",
    location: "תל אביב",
    mainImage: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=800",
    gallery: [
      "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1600607687940-47a04b629571?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&q=80&w=800"
    ]
  },
  {
    id: 2,
    title: "מגדל משרדים High-Tech",
    description: "התקנת קירות מסך (Curtain Walls) בשטח של 2,500 מ\"ר, כולל פתרונות הצללה אוטומטיים.",
    location: "הרצליה פיתוח",
    mainImage: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=800",
    gallery: [
      "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1497366811353-6870744d04b2?auto=format&fit=crop&q=80&w=800"
    ]
  },
  {
    id: 3,
    title: "מתחם מגורים 'המושבה'",
    description: "אספקה והתקנה של תריסי גלילה חשמליים וחלונות ממ\"ד ל-120 יחידות דיור.",
    location: "ראשון לציון",
    mainImage: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&q=80&w=800",
    gallery: [
      "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=800",
      "https://images.unsplash.com/photo-1515263487990-61b07816b324?auto=format&fit=crop&q=80&w=800"
    ]
  }
];

export const WHY_CHOOSE_US = [
  "ניסיון של מעל 15 שנה מול הקבלנים המובילים בישראל",
  "ייצור עצמי במפעל המאפשר שליטה מלאה על האיכות והמחיר",
  "ליווי אישי משלב התכנון ועד למסירת המפתח",
  "אחריות מלאה על כל התקנה ושירות תיקונים מהיר"
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 1,
    name: "ישראל כהן",
    role: "קבלן שלד ויזם",
    text: "עובד עם בוני הארץ כבר 5 פרויקטים. השקט הנפשי שהם נותנים לי בנושא האלומיניום והגמר הוא נכס. תמיד בזמן, תמיד מקצועי."
  },
  {
    id: 2,
    name: "מיכל לוי",
    role: "אדריכלית פנים",
    text: "הדיוק בפרטים הקטנים והיכולת לייצר פתרונות מותאמים אישית הם הסיבה שאני ממליצה עליהם לכל לקוח שלי."
  }
];

export const COLORS = {
  primary: "#1e293b", // Slate 800 - Deep Blue/Grey
  secondary: "#f59e0b", // Amber 500 - Construction Orange
  accent: "#334155", // Slate 700
  background: "#f8fafc", // Slate 50
};

export const LOGO_DESCRIPTION = "לוגו נקי ומינימליסטי. מצד ימין סמל של משולש זוויתי משולב עם קו אלומיניום דק בצבע כתום ענבר (Amber 500). שם העסק 'בוני הארץ' מופיע משמאל בפונט סנס-סריף עבה בצבע כחול-צי (Navy Blue). הסגנון משדר הנדסה, יציבות וחדשנות.";

export const HERO_IMAGE_PROMPT = "High-end modern architectural building construction site with premium aluminum window frames being installed, golden hour lighting, cinematic shot, 8k resolution, professional photography, focus on clean metal lines and glass reflections, industrial but elegant atmosphere.";
