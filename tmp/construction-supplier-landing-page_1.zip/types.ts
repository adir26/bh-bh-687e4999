
export type TemplateId = 'industrial' | 'luxury' | 'corporate' | 'modern';

export interface Service {
  id: number;
  title: string;
  description: string;
  icon: string;
}

export interface Testimonial {
  id: number;
  name: string;
  role: string;
  text: string;
}

export interface Project {
  id: number;
  title: string;
  description: string;
  location: string;
  mainImage: string;
  gallery: string[];
}

export interface BusinessInfo {
  name: string;
  specialty: string;
  area: string;
  advantage: string;
  phone: string;
  whatsapp: string;
  email: string;
}
